﻿namespace C_BankingSystem
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            SignUpBtn = new Guna.UI2.WinForms.Guna2GradientButton();
            PasswordCheckBox = new CheckBox();
            LoginBtn = new Guna.UI2.WinForms.Guna2GradientButton();
            guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            PasswordTxt = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            label5 = new Label();
            label6 = new Label();
            label4 = new Label();
            label3 = new Label();
            label1 = new Label();
            lblWelcome = new Label();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            ControlGPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            ExitBtn = new Guna.UI2.WinForms.Guna2Button();
            guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            ControlGPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 0;
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.BackColor = Color.Transparent;
            guna2GradientPanel1.Controls.Add(SignUpBtn);
            guna2GradientPanel1.Controls.Add(PasswordCheckBox);
            guna2GradientPanel1.Controls.Add(LoginBtn);
            guna2GradientPanel1.Controls.Add(guna2TextBox1);
            guna2GradientPanel1.Controls.Add(PasswordTxt);
            guna2GradientPanel1.Controls.Add(label2);
            guna2GradientPanel1.Controls.Add(label5);
            guna2GradientPanel1.Controls.Add(label6);
            guna2GradientPanel1.Controls.Add(label4);
            guna2GradientPanel1.Controls.Add(label3);
            guna2GradientPanel1.Controls.Add(label1);
            guna2GradientPanel1.Controls.Add(lblWelcome);
            guna2GradientPanel1.Controls.Add(guna2CirclePictureBox1);
            guna2GradientPanel1.CustomizableEdges = customizableEdges10;
            guna2GradientPanel1.Dock = DockStyle.Fill;
            guna2GradientPanel1.FillColor = Color.Indigo;
            guna2GradientPanel1.FillColor2 = Color.Purple;
            guna2GradientPanel1.Location = new Point(0, 0);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges11;
            guna2GradientPanel1.Size = new Size(1931, 1092);
            guna2GradientPanel1.TabIndex = 0;
            // 
            // SignUpBtn
            // 
            SignUpBtn.BorderColor = Color.White;
            SignUpBtn.BorderRadius = 15;
            SignUpBtn.BorderThickness = 2;
            SignUpBtn.CustomizableEdges = customizableEdges1;
            SignUpBtn.DisabledState.BorderColor = Color.DarkGray;
            SignUpBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            SignUpBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            SignUpBtn.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            SignUpBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            SignUpBtn.FillColor = Color.Transparent;
            SignUpBtn.FillColor2 = Color.Transparent;
            SignUpBtn.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            SignUpBtn.ForeColor = Color.White;
            SignUpBtn.Location = new Point(1683, 57);
            SignUpBtn.Name = "SignUpBtn";
            SignUpBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            SignUpBtn.Size = new Size(154, 44);
            SignUpBtn.TabIndex = 6;
            SignUpBtn.Text = "Sign Up";
            SignUpBtn.TextOffset = new Point(0, -4);
            SignUpBtn.Click += SignUpBtn_Click;
            // 
            // PasswordCheckBox
            // 
            PasswordCheckBox.AutoSize = true;
            PasswordCheckBox.Location = new Point(1228, 742);
            PasswordCheckBox.Name = "PasswordCheckBox";
            PasswordCheckBox.Size = new Size(28, 27);
            PasswordCheckBox.TabIndex = 5;
            PasswordCheckBox.UseVisualStyleBackColor = true;
            PasswordCheckBox.CheckedChanged += PasswordCheckBox_CheckedChanged;
            // 
            // LoginBtn
            // 
            LoginBtn.BorderColor = Color.White;
            LoginBtn.BorderRadius = 15;
            LoginBtn.BorderThickness = 2;
            LoginBtn.CustomizableEdges = customizableEdges3;
            LoginBtn.DisabledState.BorderColor = Color.DarkGray;
            LoginBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            LoginBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            LoginBtn.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            LoginBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            LoginBtn.FillColor = Color.Transparent;
            LoginBtn.FillColor2 = Color.Transparent;
            LoginBtn.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            LoginBtn.ForeColor = Color.White;
            LoginBtn.Location = new Point(551, 788);
            LoginBtn.Name = "LoginBtn";
            LoginBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            LoginBtn.Size = new Size(211, 69);
            LoginBtn.TabIndex = 4;
            LoginBtn.Text = "Login";
            LoginBtn.Click += LoginBtn_Click;
            // 
            // guna2TextBox1
            // 
            guna2TextBox1.BorderRadius = 15;
            guna2TextBox1.Cursor = Cursors.IBeam;
            guna2TextBox1.CustomizableEdges = customizableEdges5;
            guna2TextBox1.DefaultText = "";
            guna2TextBox1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.FillColor = Color.Silver;
            guna2TextBox1.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Font = new Font("Segoe UI", 9F);
            guna2TextBox1.ForeColor = Color.Black;
            guna2TextBox1.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Location = new Point(832, 536);
            guna2TextBox1.Margin = new Padding(6, 7, 6, 7);
            guna2TextBox1.Name = "guna2TextBox1";
            guna2TextBox1.PasswordChar = '\0';
            guna2TextBox1.PlaceholderForeColor = Color.DimGray;
            guna2TextBox1.PlaceholderText = "";
            guna2TextBox1.SelectedText = "";
            guna2TextBox1.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2TextBox1.Size = new Size(424, 49);
            guna2TextBox1.TabIndex = 3;
            // 
            // PasswordTxt
            // 
            PasswordTxt.BorderRadius = 15;
            PasswordTxt.CustomizableEdges = customizableEdges7;
            PasswordTxt.DefaultText = "";
            PasswordTxt.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            PasswordTxt.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            PasswordTxt.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            PasswordTxt.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            PasswordTxt.FillColor = Color.Silver;
            PasswordTxt.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            PasswordTxt.Font = new Font("Segoe UI", 9F);
            PasswordTxt.ForeColor = Color.Black;
            PasswordTxt.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            PasswordTxt.Location = new Point(832, 656);
            PasswordTxt.Margin = new Padding(6, 7, 6, 7);
            PasswordTxt.Name = "PasswordTxt";
            PasswordTxt.PasswordChar = '*';
            PasswordTxt.PlaceholderForeColor = Color.DimGray;
            PasswordTxt.PlaceholderText = "";
            PasswordTxt.SelectedText = "";
            PasswordTxt.ShadowDecoration.CustomizableEdges = customizableEdges8;
            PasswordTxt.Size = new Size(424, 49);
            PasswordTxt.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Century Gothic", 14F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(694, 213);
            label2.Name = "label2";
            label2.Size = new Size(619, 49);
            label2.TabIndex = 1;
            label2.Text = "Commercial Bank Of Ethiopia";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Century Gothic", 14F, FontStyle.Bold);
            label5.ForeColor = Color.White;
            label5.Location = new Point(551, 656);
            label5.Name = "label5";
            label5.Size = new Size(211, 49);
            label5.TabIndex = 1;
            label5.Text = "Password";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label6.ForeColor = Color.White;
            label6.Location = new Point(974, 735);
            label6.Name = "label6";
            label6.Size = new Size(238, 37);
            label6.TabIndex = 1;
            label6.Text = "Show Password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Century Gothic", 14F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(551, 536);
            label4.Name = "label4";
            label4.Size = new Size(225, 49);
            label4.TabIndex = 1;
            label4.Text = "Username";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Century Gothic", 14F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(927, 388);
            label3.Name = "label3";
            label3.Size = new Size(130, 49);
            label3.TabIndex = 1;
            label3.Text = "Login";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Century Gothic", 9F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(1268, 57);
            label1.Name = "label1";
            label1.Size = new Size(343, 33);
            label1.TabIndex = 1;
            label1.Text = "Don't have an account ?";
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.BackColor = Color.Transparent;
            lblWelcome.Font = new Font("Century Gothic", 14F, FontStyle.Bold);
            lblWelcome.ForeColor = Color.White;
            lblWelcome.Location = new Point(878, 101);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(241, 49);
            lblWelcome.TabIndex = 1;
            lblWelcome.Text = "Welcome !";
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.BackColor = Color.Transparent;
            guna2CirclePictureBox1.Image = (Image)resources.GetObject("guna2CirclePictureBox1.Image");
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new Point(3, 46);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges9;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(419, 328);
            guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2CirclePictureBox1.TabIndex = 0;
            guna2CirclePictureBox1.TabStop = false;
            // 
            // ControlGPanel2
            // 
            ControlGPanel2.Controls.Add(ExitBtn);
            ControlGPanel2.CustomizableEdges = customizableEdges14;
            ControlGPanel2.FillColor = Color.Indigo;
            ControlGPanel2.FillColor2 = Color.Purple;
            ControlGPanel2.Location = new Point(-2, 0);
            ControlGPanel2.Name = "ControlGPanel2";
            ControlGPanel2.ShadowDecoration.CustomizableEdges = customizableEdges15;
            ControlGPanel2.Size = new Size(1933, 51);
            ControlGPanel2.TabIndex = 7;
            // 
            // ExitBtn
            // 
            ExitBtn.BackColor = Color.Transparent;
            ExitBtn.BorderColor = Color.White;
            ExitBtn.CustomizableEdges = customizableEdges12;
            ExitBtn.DisabledState.BorderColor = Color.DarkGray;
            ExitBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            ExitBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            ExitBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            ExitBtn.FillColor = Color.Transparent;
            ExitBtn.Font = new Font("Segoe UI", 9F);
            ExitBtn.ForeColor = Color.White;
            ExitBtn.Image = (Image)resources.GetObject("ExitBtn.Image");
            ExitBtn.ImageSize = new Size(40, 40);
            ExitBtn.Location = new Point(1859, 3);
            ExitBtn.Name = "ExitBtn";
            ExitBtn.ShadowDecoration.CustomizableEdges = customizableEdges13;
            ExitBtn.Size = new Size(74, 45);
            ExitBtn.TabIndex = 8;
            ExitBtn.Click += ExitBtn_Click;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(15F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1931, 1092);
            Controls.Add(ControlGPanel2);
            Controls.Add(guna2GradientPanel1);
            FormBorderStyle = FormBorderStyle.None;
            IsMdiContainer = true;
            Name = "LoginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CBE Online Banking Login";
            guna2GradientPanel1.ResumeLayout(false);
            guna2GradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            ControlGPanel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Label label2;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label lblWelcome;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox PasswordTxt;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2GradientButton LoginBtn;
        private Label label1;
        private CheckBox PasswordCheckBox;
        private Label label6;
        private Guna.UI2.WinForms.Guna2GradientButton SignUpBtn;
        private Guna.UI2.WinForms.Guna2GradientPanel ControlGPanel2;
        private Guna.UI2.WinForms.Guna2Button ExitBtn;
    }
}
