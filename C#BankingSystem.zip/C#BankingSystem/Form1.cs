namespace C_BankingSystem
{
    public partial class LoginForm : Form
    {

        SignUpForm signUpForm;
        MainPage mainPage;
        public LoginForm()
        {
            InitializeComponent();
        }



        private void PasswordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (PasswordCheckBox.Checked)
            {
                PasswordTxt.PasswordChar = '\0';
            }
            else
            {
                PasswordTxt.PasswordChar = '*';
            }
        }

        private void SignUpBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            signUpForm = new SignUpForm();
            signUpForm.Show();
            /* if(signUpForm == null)
             {
                 signUpForm = new SignUpForm();
                 signUpForm.FormClosed += SignUpForm_FormClosed;
                 signUpForm.MdiParent = this;
                 signUpForm.Dock = DockStyle.Fill;
                 loginForm = new LoginForm();
                 guna2GradientPanel1.Hide();
                 loginForm.Hide();
                 signUpForm.Show();
             }
             else
             {
                 signUpForm.Activate();
             }*/
        }

        /*   private void SignUpForm_FormClosed(object sender, FormClosedEventArgs e)
           {
               signUpForm = null;
           }*/

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainPage = new MainPage();
            mainPage.Show();
            
        }
    }
}
