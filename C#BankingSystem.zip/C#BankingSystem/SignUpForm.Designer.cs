﻿namespace C_BankingSystem
{
    partial class SignUpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUpForm));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            ShowBtn = new Guna.UI2.WinForms.Guna2Button();
            ControlGPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            ExitBtn = new Guna.UI2.WinForms.Guna2Button();
            PasswordTxt2 = new Guna.UI2.WinForms.Guna2TextBox();
            ConfirmPasswordTxt = new Guna.UI2.WinForms.Guna2TextBox();
            label6 = new Label();
            label9 = new Label();
            LastNameTxt = new Guna.UI2.WinForms.Guna2TextBox();
            PhoneNumberTxt = new Guna.UI2.WinForms.Guna2TextBox();
            label7 = new Label();
            label8 = new Label();
            LoginBtn = new Guna.UI2.WinForms.Guna2GradientButton();
            guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            AccountNumberTxt = new Guna.UI2.WinForms.Guna2TextBox();
            FirstNameTxt = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label1 = new Label();
            lblWelcome = new Label();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            guna2GradientPanel2.SuspendLayout();
            ControlGPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2GradientPanel2
            // 
            guna2GradientPanel2.BackColor = Color.Transparent;
            guna2GradientPanel2.Controls.Add(ShowBtn);
            guna2GradientPanel2.Controls.Add(ControlGPanel2);
            guna2GradientPanel2.Controls.Add(PasswordTxt2);
            guna2GradientPanel2.Controls.Add(ConfirmPasswordTxt);
            guna2GradientPanel2.Controls.Add(label6);
            guna2GradientPanel2.Controls.Add(label9);
            guna2GradientPanel2.Controls.Add(LastNameTxt);
            guna2GradientPanel2.Controls.Add(PhoneNumberTxt);
            guna2GradientPanel2.Controls.Add(label7);
            guna2GradientPanel2.Controls.Add(label8);
            guna2GradientPanel2.Controls.Add(LoginBtn);
            guna2GradientPanel2.Controls.Add(guna2GradientButton1);
            guna2GradientPanel2.Controls.Add(AccountNumberTxt);
            guna2GradientPanel2.Controls.Add(FirstNameTxt);
            guna2GradientPanel2.Controls.Add(label2);
            guna2GradientPanel2.Controls.Add(label5);
            guna2GradientPanel2.Controls.Add(label4);
            guna2GradientPanel2.Controls.Add(label3);
            guna2GradientPanel2.Controls.Add(label1);
            guna2GradientPanel2.Controls.Add(lblWelcome);
            guna2GradientPanel2.Controls.Add(guna2CirclePictureBox1);
            guna2GradientPanel2.CustomizableEdges = customizableEdges24;
            guna2GradientPanel2.Dock = DockStyle.Fill;
            guna2GradientPanel2.FillColor = Color.Indigo;
            guna2GradientPanel2.FillColor2 = Color.Purple;
            guna2GradientPanel2.Location = new Point(0, 0);
            guna2GradientPanel2.Name = "guna2GradientPanel2";
            guna2GradientPanel2.ShadowDecoration.CustomizableEdges = customizableEdges25;
            guna2GradientPanel2.Size = new Size(1931, 1092);
            guna2GradientPanel2.TabIndex = 1;
            // 
            // ShowBtn
            // 
            ShowBtn.CustomizableEdges = customizableEdges1;
            ShowBtn.DisabledState.BorderColor = Color.DarkGray;
            ShowBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            ShowBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            ShowBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            ShowBtn.FillColor = Color.Transparent;
            ShowBtn.Font = new Font("Segoe UI", 9F);
            ShowBtn.ForeColor = Color.White;
            ShowBtn.Image = (Image)resources.GetObject("ShowBtn.Image");
            ShowBtn.ImageSize = new Size(50, 50);
            ShowBtn.Location = new Point(1287, 737);
            ShowBtn.Name = "ShowBtn";
            ShowBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            ShowBtn.Size = new Size(61, 37);
            ShowBtn.TabIndex = 16;
            ShowBtn.MouseDown += ShowBtn_MouseDown;
            ShowBtn.MouseUp += ShowBtn_MouseUp;
            // 
            // ControlGPanel2
            // 
            ControlGPanel2.Controls.Add(ExitBtn);
            ControlGPanel2.CustomizableEdges = customizableEdges5;
            ControlGPanel2.FillColor = Color.Indigo;
            ControlGPanel2.FillColor2 = Color.Purple;
            ControlGPanel2.Location = new Point(0, 0);
            ControlGPanel2.Name = "ControlGPanel2";
            ControlGPanel2.ShadowDecoration.CustomizableEdges = customizableEdges6;
            ControlGPanel2.Size = new Size(1933, 51);
            ControlGPanel2.TabIndex = 15;
            // 
            // ExitBtn
            // 
            ExitBtn.BackColor = Color.Transparent;
            ExitBtn.BorderColor = Color.White;
            ExitBtn.CustomizableEdges = customizableEdges3;
            ExitBtn.DisabledState.BorderColor = Color.DarkGray;
            ExitBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            ExitBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            ExitBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            ExitBtn.FillColor = Color.Transparent;
            ExitBtn.Font = new Font("Segoe UI", 9F);
            ExitBtn.ForeColor = Color.White;
            ExitBtn.Image = (Image)resources.GetObject("ExitBtn.Image");
            ExitBtn.ImageSize = new Size(40, 40);
            ExitBtn.Location = new Point(1859, 3);
            ExitBtn.Name = "ExitBtn";
            ExitBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            ExitBtn.Size = new Size(74, 45);
            ExitBtn.TabIndex = 8;
            ExitBtn.Click += ExitBtn_Click;
            // 
            // PasswordTxt2
            // 
            PasswordTxt2.BorderRadius = 15;
            PasswordTxt2.Cursor = Cursors.IBeam;
            PasswordTxt2.CustomizableEdges = customizableEdges7;
            PasswordTxt2.DefaultText = "";
            PasswordTxt2.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            PasswordTxt2.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            PasswordTxt2.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            PasswordTxt2.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            PasswordTxt2.FillColor = Color.Silver;
            PasswordTxt2.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            PasswordTxt2.Font = new Font("Segoe UI", 9F);
            PasswordTxt2.ForeColor = Color.Black;
            PasswordTxt2.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            PasswordTxt2.Location = new Point(869, 737);
            PasswordTxt2.Margin = new Padding(6, 7, 6, 7);
            PasswordTxt2.Name = "PasswordTxt2";
            PasswordTxt2.PasswordChar = '*';
            PasswordTxt2.PlaceholderForeColor = Color.DimGray;
            PasswordTxt2.PlaceholderText = "";
            PasswordTxt2.SelectedText = "";
            PasswordTxt2.ShadowDecoration.CustomizableEdges = customizableEdges8;
            PasswordTxt2.Size = new Size(409, 37);
            PasswordTxt2.TabIndex = 14;
            // 
            // ConfirmPasswordTxt
            // 
            ConfirmPasswordTxt.BorderRadius = 15;
            ConfirmPasswordTxt.CustomizableEdges = customizableEdges9;
            ConfirmPasswordTxt.DefaultText = "";
            ConfirmPasswordTxt.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            ConfirmPasswordTxt.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            ConfirmPasswordTxt.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            ConfirmPasswordTxt.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            ConfirmPasswordTxt.FillColor = Color.Silver;
            ConfirmPasswordTxt.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            ConfirmPasswordTxt.Font = new Font("Segoe UI", 9F);
            ConfirmPasswordTxt.ForeColor = Color.Black;
            ConfirmPasswordTxt.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            ConfirmPasswordTxt.Location = new Point(869, 821);
            ConfirmPasswordTxt.Margin = new Padding(6, 7, 6, 7);
            ConfirmPasswordTxt.Name = "ConfirmPasswordTxt";
            ConfirmPasswordTxt.PasswordChar = '*';
            ConfirmPasswordTxt.PlaceholderForeColor = Color.DimGray;
            ConfirmPasswordTxt.PlaceholderText = "";
            ConfirmPasswordTxt.SelectedText = "";
            ConfirmPasswordTxt.ShadowDecoration.CustomizableEdges = customizableEdges10;
            ConfirmPasswordTxt.Size = new Size(409, 37);
            ConfirmPasswordTxt.TabIndex = 13;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label6.ForeColor = Color.White;
            label6.Location = new Point(544, 821);
            label6.Name = "label6";
            label6.Size = new Size(274, 37);
            label6.TabIndex = 11;
            label6.Text = "Confirm Password";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label9.ForeColor = Color.White;
            label9.Location = new Point(665, 737);
            label9.Name = "label9";
            label9.Size = new Size(153, 37);
            label9.TabIndex = 12;
            label9.Text = "Password";
            // 
            // LastNameTxt
            // 
            LastNameTxt.BorderRadius = 15;
            LastNameTxt.Cursor = Cursors.IBeam;
            LastNameTxt.CustomizableEdges = customizableEdges11;
            LastNameTxt.DefaultText = "";
            LastNameTxt.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            LastNameTxt.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            LastNameTxt.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            LastNameTxt.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            LastNameTxt.FillColor = Color.Silver;
            LastNameTxt.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            LastNameTxt.Font = new Font("Segoe UI", 9F);
            LastNameTxt.ForeColor = Color.Black;
            LastNameTxt.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            LastNameTxt.Location = new Point(871, 573);
            LastNameTxt.Margin = new Padding(6, 7, 6, 7);
            LastNameTxt.Name = "LastNameTxt";
            LastNameTxt.PasswordChar = '\0';
            LastNameTxt.PlaceholderForeColor = Color.DimGray;
            LastNameTxt.PlaceholderText = "";
            LastNameTxt.SelectedText = "";
            LastNameTxt.ShadowDecoration.CustomizableEdges = customizableEdges12;
            LastNameTxt.Size = new Size(409, 37);
            LastNameTxt.TabIndex = 10;
            // 
            // PhoneNumberTxt
            // 
            PhoneNumberTxt.BorderRadius = 15;
            PhoneNumberTxt.CustomizableEdges = customizableEdges13;
            PhoneNumberTxt.DefaultText = "";
            PhoneNumberTxt.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            PhoneNumberTxt.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            PhoneNumberTxt.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            PhoneNumberTxt.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            PhoneNumberTxt.FillColor = Color.Silver;
            PhoneNumberTxt.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            PhoneNumberTxt.Font = new Font("Segoe UI", 9F);
            PhoneNumberTxt.ForeColor = Color.Black;
            PhoneNumberTxt.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            PhoneNumberTxt.Location = new Point(871, 657);
            PhoneNumberTxt.Margin = new Padding(6, 7, 6, 7);
            PhoneNumberTxt.Name = "PhoneNumberTxt";
            PhoneNumberTxt.PasswordChar = '*';
            PhoneNumberTxt.PlaceholderForeColor = Color.DimGray;
            PhoneNumberTxt.PlaceholderText = "";
            PhoneNumberTxt.SelectedText = "";
            PhoneNumberTxt.ShadowDecoration.CustomizableEdges = customizableEdges14;
            PhoneNumberTxt.Size = new Size(409, 37);
            PhoneNumberTxt.TabIndex = 9;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label7.ForeColor = Color.White;
            label7.Location = new Point(585, 657);
            label7.Name = "label7";
            label7.Size = new Size(233, 37);
            label7.TabIndex = 7;
            label7.Text = "Phone Number";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label8.ForeColor = Color.White;
            label8.Location = new Point(649, 573);
            label8.Name = "label8";
            label8.Size = new Size(169, 37);
            label8.TabIndex = 8;
            label8.Text = "Last Name";
            // 
            // LoginBtn
            // 
            LoginBtn.BorderColor = Color.White;
            LoginBtn.BorderRadius = 15;
            LoginBtn.BorderThickness = 2;
            LoginBtn.CustomizableEdges = customizableEdges15;
            LoginBtn.DisabledState.BorderColor = Color.DarkGray;
            LoginBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            LoginBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            LoginBtn.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            LoginBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            LoginBtn.FillColor = Color.Transparent;
            LoginBtn.FillColor2 = Color.Transparent;
            LoginBtn.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            LoginBtn.ForeColor = Color.White;
            LoginBtn.Location = new Point(1683, 57);
            LoginBtn.Name = "LoginBtn";
            LoginBtn.ShadowDecoration.CustomizableEdges = customizableEdges16;
            LoginBtn.Size = new Size(154, 44);
            LoginBtn.TabIndex = 6;
            LoginBtn.Text = "Login";
            LoginBtn.TextOffset = new Point(0, -4);
            LoginBtn.Click += LoginBtn_Click;
            // 
            // guna2GradientButton1
            // 
            guna2GradientButton1.BorderColor = Color.White;
            guna2GradientButton1.BorderRadius = 15;
            guna2GradientButton1.BorderThickness = 2;
            guna2GradientButton1.CustomizableEdges = customizableEdges17;
            guna2GradientButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton1.FillColor = Color.Transparent;
            guna2GradientButton1.FillColor2 = Color.Transparent;
            guna2GradientButton1.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            guna2GradientButton1.ForeColor = Color.White;
            guna2GradientButton1.Location = new Point(1072, 896);
            guna2GradientButton1.Name = "guna2GradientButton1";
            guna2GradientButton1.ShadowDecoration.CustomizableEdges = customizableEdges18;
            guna2GradientButton1.Size = new Size(208, 49);
            guna2GradientButton1.TabIndex = 4;
            guna2GradientButton1.Text = "Sign Up";
            // 
            // AccountNumberTxt
            // 
            AccountNumberTxt.BorderRadius = 15;
            AccountNumberTxt.Cursor = Cursors.IBeam;
            AccountNumberTxt.CustomizableEdges = customizableEdges19;
            AccountNumberTxt.DefaultText = "";
            AccountNumberTxt.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            AccountNumberTxt.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            AccountNumberTxt.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            AccountNumberTxt.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            AccountNumberTxt.FillColor = Color.Silver;
            AccountNumberTxt.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            AccountNumberTxt.Font = new Font("Segoe UI", 9F);
            AccountNumberTxt.ForeColor = Color.Black;
            AccountNumberTxt.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            AccountNumberTxt.Location = new Point(871, 404);
            AccountNumberTxt.Margin = new Padding(6, 7, 6, 7);
            AccountNumberTxt.Name = "AccountNumberTxt";
            AccountNumberTxt.PasswordChar = '\0';
            AccountNumberTxt.PlaceholderForeColor = Color.DimGray;
            AccountNumberTxt.PlaceholderText = "";
            AccountNumberTxt.SelectedText = "";
            AccountNumberTxt.ShadowDecoration.CustomizableEdges = customizableEdges20;
            AccountNumberTxt.Size = new Size(409, 37);
            AccountNumberTxt.TabIndex = 3;
            // 
            // FirstNameTxt
            // 
            FirstNameTxt.BorderRadius = 15;
            FirstNameTxt.CustomizableEdges = customizableEdges21;
            FirstNameTxt.DefaultText = "";
            FirstNameTxt.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            FirstNameTxt.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            FirstNameTxt.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            FirstNameTxt.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            FirstNameTxt.FillColor = Color.Silver;
            FirstNameTxt.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            FirstNameTxt.Font = new Font("Segoe UI", 9F);
            FirstNameTxt.ForeColor = Color.Black;
            FirstNameTxt.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            FirstNameTxt.Location = new Point(871, 488);
            FirstNameTxt.Margin = new Padding(6, 7, 6, 7);
            FirstNameTxt.Name = "FirstNameTxt";
            FirstNameTxt.PasswordChar = '*';
            FirstNameTxt.PlaceholderForeColor = Color.DimGray;
            FirstNameTxt.PlaceholderText = "";
            FirstNameTxt.SelectedText = "";
            FirstNameTxt.ShadowDecoration.CustomizableEdges = customizableEdges22;
            FirstNameTxt.Size = new Size(409, 37);
            FirstNameTxt.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Century Gothic", 14F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(694, 213);
            label2.Name = "label2";
            label2.Size = new Size(619, 49);
            label2.TabIndex = 1;
            label2.Text = "Commercial Bank Of Ethiopia";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label5.ForeColor = Color.White;
            label5.Location = new Point(651, 488);
            label5.Name = "label5";
            label5.Size = new Size(167, 37);
            label5.TabIndex = 1;
            label5.Text = "First Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(552, 404);
            label4.Name = "label4";
            label4.Size = new Size(266, 37);
            label4.TabIndex = 1;
            label4.Text = "Account Number";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Century Gothic", 14F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(900, 325);
            label3.Name = "label3";
            label3.Size = new Size(174, 49);
            label3.TabIndex = 1;
            label3.Text = "Sign Up";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Century Gothic", 9F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(1268, 57);
            label1.Name = "label1";
            label1.Size = new Size(384, 33);
            label1.TabIndex = 1;
            label1.Text = "Already have an account ? ";
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.BackColor = Color.Transparent;
            lblWelcome.Font = new Font("Century Gothic", 14F, FontStyle.Bold);
            lblWelcome.ForeColor = Color.White;
            lblWelcome.Location = new Point(878, 101);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(241, 49);
            lblWelcome.TabIndex = 1;
            lblWelcome.Text = "Welcome !";
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.BackColor = Color.Transparent;
            guna2CirclePictureBox1.Image = (Image)resources.GetObject("guna2CirclePictureBox1.Image");
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new Point(3, 46);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges23;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(419, 328);
            guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2CirclePictureBox1.TabIndex = 0;
            guna2CirclePictureBox1.TabStop = false;
            // 
            // SignUpForm
            // 
            AutoScaleDimensions = new SizeF(15F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1931, 1092);
            Controls.Add(guna2GradientPanel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "SignUpForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SignUpForm";
            guna2GradientPanel2.ResumeLayout(false);
            guna2GradientPanel2.PerformLayout();
            ControlGPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            ResumeLayout(false);
        }

        private void ShowBtn2_MouseDown(object sender, MouseEventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2TextBox LastNameTxt;
        private Guna.UI2.WinForms.Guna2TextBox PhoneNumberTxt;
        private Label label7;
        private Label label8;
        private Guna.UI2.WinForms.Guna2GradientButton LoginBtn;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2TextBox AccountNumberTxt;
        private Guna.UI2.WinForms.Guna2TextBox FirstNameTxt;
        private Label label2;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label1;
        private Label lblWelcome;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox PasswordTxt2;
        private Guna.UI2.WinForms.Guna2TextBox ConfirmPasswordTxt;
        private Label label6;
        private Label label9;
        private Guna.UI2.WinForms.Guna2GradientPanel ControlGPanel2;
        private Guna.UI2.WinForms.Guna2Button ExitBtn;
        private Guna.UI2.WinForms.Guna2Button ShowBtn;
    }
}