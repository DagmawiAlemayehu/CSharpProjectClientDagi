﻿namespace C_BankingSystem
{
    partial class MainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainPage));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            SidebarTransiton = new System.Windows.Forms.Timer(components);
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            ControlGPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            ExpandBtn = new Guna.UI2.WinForms.Guna2Button();
            sidebarGradientPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            ExitBtn = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            ControlGPanel2.SuspendLayout();
            sidebarGradientPanel.SuspendLayout();
            SuspendLayout();
            // 
            // guna2Button7
            // 
            guna2Button7.CustomizableEdges = customizableEdges1;
            guna2Button7.DisabledState.BorderColor = Color.DarkGray;
            guna2Button7.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button7.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button7.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button7.FillColor = Color.White;
            guna2Button7.Font = new Font("Century Gothic", 11F, FontStyle.Bold);
            guna2Button7.ForeColor = Color.Purple;
            guna2Button7.Image = (Image)resources.GetObject("guna2Button7.Image");
            guna2Button7.ImageOffset = new Point(-20, 0);
            guna2Button7.ImageSize = new Size(50, 50);
            guna2Button7.Location = new Point(0, 928);
            guna2Button7.Name = "guna2Button7";
            guna2Button7.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Button7.Size = new Size(369, 74);
            guna2Button7.TabIndex = 2;
            guna2Button7.Text = "Log Out";
            // 
            // guna2Button6
            // 
            guna2Button6.CustomizableEdges = customizableEdges3;
            guna2Button6.DisabledState.BorderColor = Color.DarkGray;
            guna2Button6.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button6.FillColor = Color.White;
            guna2Button6.Font = new Font("Century Gothic", 11F, FontStyle.Bold);
            guna2Button6.ForeColor = Color.Purple;
            guna2Button6.Image = (Image)resources.GetObject("guna2Button6.Image");
            guna2Button6.ImageOffset = new Point(-20, 0);
            guna2Button6.ImageSize = new Size(60, 60);
            guna2Button6.Location = new Point(0, 832);
            guna2Button6.Name = "guna2Button6";
            guna2Button6.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Button6.Size = new Size(369, 75);
            guna2Button6.TabIndex = 2;
            guna2Button6.Text = "Settings";
            // 
            // guna2Button5
            // 
            guna2Button5.CustomizableEdges = customizableEdges5;
            guna2Button5.DisabledState.BorderColor = Color.DarkGray;
            guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button5.FillColor = Color.White;
            guna2Button5.Font = new Font("Century Gothic", 11F, FontStyle.Bold);
            guna2Button5.ForeColor = Color.Purple;
            guna2Button5.Image = (Image)resources.GetObject("guna2Button5.Image");
            guna2Button5.ImageOffset = new Point(-23, 0);
            guna2Button5.ImageSize = new Size(50, 50);
            guna2Button5.Location = new Point(0, 532);
            guna2Button5.Name = "guna2Button5";
            guna2Button5.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Button5.Size = new Size(372, 77);
            guna2Button5.TabIndex = 2;
            guna2Button5.Text = "Recents";
            // 
            // guna2Button4
            // 
            guna2Button4.CustomizableEdges = customizableEdges7;
            guna2Button4.DisabledState.BorderColor = Color.DarkGray;
            guna2Button4.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button4.FillColor = Color.White;
            guna2Button4.Font = new Font("Century Gothic", 11F, FontStyle.Bold);
            guna2Button4.ForeColor = Color.Purple;
            guna2Button4.Image = (Image)resources.GetObject("guna2Button4.Image");
            guna2Button4.ImageOffset = new Point(-15, 0);
            guna2Button4.ImageSize = new Size(55, 55);
            guna2Button4.Location = new Point(0, 431);
            guna2Button4.Name = "guna2Button4";
            guna2Button4.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2Button4.Size = new Size(372, 77);
            guna2Button4.TabIndex = 2;
            guna2Button4.Text = "Accounts";
            // 
            // guna2Button3
            // 
            guna2Button3.CustomizableEdges = customizableEdges9;
            guna2Button3.DisabledState.BorderColor = Color.DarkGray;
            guna2Button3.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button3.FillColor = Color.White;
            guna2Button3.Font = new Font("Century Gothic", 11F, FontStyle.Bold);
            guna2Button3.ForeColor = Color.Purple;
            guna2Button3.Image = (Image)resources.GetObject("guna2Button3.Image");
            guna2Button3.ImageOffset = new Point(-25, 0);
            guna2Button3.ImageSize = new Size(45, 45);
            guna2Button3.Location = new Point(0, 322);
            guna2Button3.Name = "guna2Button3";
            guna2Button3.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2Button3.Size = new Size(372, 77);
            guna2Button3.TabIndex = 2;
            guna2Button3.Text = "Transfer";
            // 
            // guna2Button2
            // 
            guna2Button2.CustomizableEdges = customizableEdges11;
            guna2Button2.DisabledState.BorderColor = Color.DarkGray;
            guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button2.FillColor = Color.White;
            guna2Button2.Font = new Font("Century Gothic", 11F, FontStyle.Bold);
            guna2Button2.ForeColor = Color.Purple;
            guna2Button2.Image = (Image)resources.GetObject("guna2Button2.Image");
            guna2Button2.ImageOffset = new Point(-10, 0);
            guna2Button2.ImageSize = new Size(50, 50);
            guna2Button2.Location = new Point(0, 204);
            guna2Button2.Name = "guna2Button2";
            guna2Button2.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2Button2.Size = new Size(369, 77);
            guna2Button2.TabIndex = 2;
            guna2Button2.Text = "Dashboard";
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.BackColor = Color.Transparent;
            guna2CirclePictureBox1.FillColor = Color.Transparent;
            guna2CirclePictureBox1.Image = (Image)resources.GetObject("guna2CirclePictureBox1.Image");
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new Point(0, 0);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges13;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(139, 131);
            guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2CirclePictureBox1.TabIndex = 2;
            guna2CirclePictureBox1.TabStop = false;
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.CustomizableEdges = customizableEdges14;
            guna2GradientPanel1.FillColor = Color.Indigo;
            guna2GradientPanel1.FillColor2 = Color.Peru;
            guna2GradientPanel1.Location = new Point(365, 49);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges15;
            guna2GradientPanel1.Size = new Size(1567, 1045);
            guna2GradientPanel1.TabIndex = 1;
            // 
            // ControlGPanel2
            // 
            ControlGPanel2.BackColor = Color.Black;
            ControlGPanel2.Controls.Add(ExpandBtn);
            ControlGPanel2.Controls.Add(ExitBtn);
            ControlGPanel2.CustomizableEdges = customizableEdges20;
            ControlGPanel2.FillColor = Color.Indigo;
            ControlGPanel2.FillColor2 = Color.Peru;
            ControlGPanel2.Location = new Point(-1, 0);
            ControlGPanel2.Name = "ControlGPanel2";
            ControlGPanel2.ShadowDecoration.CustomizableEdges = customizableEdges21;
            ControlGPanel2.Size = new Size(1932, 51);
            ControlGPanel2.TabIndex = 9;
            // 
            // ExpandBtn
            // 
            ExpandBtn.BackColor = Color.Transparent;
            ExpandBtn.BorderColor = Color.White;
            ExpandBtn.CustomizableEdges = customizableEdges16;
            ExpandBtn.DisabledState.BorderColor = Color.DarkGray;
            ExpandBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            ExpandBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            ExpandBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            ExpandBtn.FillColor = Color.Transparent;
            ExpandBtn.Font = new Font("Segoe UI", 9F);
            ExpandBtn.ForeColor = Color.White;
            ExpandBtn.Image = (Image)resources.GetObject("ExpandBtn.Image");
            ExpandBtn.ImageSize = new Size(40, 40);
            ExpandBtn.Location = new Point(0, 3);
            ExpandBtn.Name = "ExpandBtn";
            ExpandBtn.ShadowDecoration.CustomizableEdges = customizableEdges17;
            ExpandBtn.Size = new Size(74, 45);
            ExpandBtn.TabIndex = 8;

            // 
            // sidebarGradientPanel
            // 
            sidebarGradientPanel.BackColor = Color.White;
            sidebarGradientPanel.Controls.Add(guna2Button7);
            sidebarGradientPanel.Controls.Add(guna2CirclePictureBox1);
            sidebarGradientPanel.Controls.Add(guna2Button2);
            sidebarGradientPanel.Controls.Add(guna2Button6);
            sidebarGradientPanel.Controls.Add(guna2Button3);
            sidebarGradientPanel.Controls.Add(guna2Button4);
            sidebarGradientPanel.Controls.Add(guna2Button5);
            sidebarGradientPanel.CustomizableEdges = customizableEdges22;
            sidebarGradientPanel.FillColor = Color.Purple;
            sidebarGradientPanel.FillColor2 = Color.Indigo;
            sidebarGradientPanel.Location = new Point(-1, 49);
            sidebarGradientPanel.Name = "sidebarGradientPanel";
            sidebarGradientPanel.ShadowDecoration.CustomizableEdges = customizableEdges23;
            sidebarGradientPanel.Size = new Size(369, 1045);
            sidebarGradientPanel.TabIndex = 0;
            // 
            // ExitBtn
            // 
            ExitBtn.BackColor = Color.Transparent;
            ExitBtn.BorderColor = Color.White;
            ExitBtn.CustomizableEdges = customizableEdges18;
            ExitBtn.DisabledState.BorderColor = Color.DarkGray;
            ExitBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            ExitBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            ExitBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            ExitBtn.FillColor = Color.Transparent;
            ExitBtn.Font = new Font("Segoe UI", 9F);
            ExitBtn.ForeColor = Color.White;
            ExitBtn.Image = (Image)resources.GetObject("ExitBtn.Image");
            ExitBtn.ImageSize = new Size(40, 40);
            ExitBtn.Location = new Point(1859, 3);
            ExitBtn.Name = "ExitBtn";
            ExitBtn.ShadowDecoration.CustomizableEdges = customizableEdges19;
            ExitBtn.Size = new Size(74, 45);
            ExitBtn.TabIndex = 8;
            // 
            // MainPage
            // 
            AutoScaleDimensions = new SizeF(15F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1931, 1092);
            Controls.Add(sidebarGradientPanel);
            Controls.Add(ControlGPanel2);
            Controls.Add(guna2GradientPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "MainPage";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MainPage";
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            ControlGPanel2.ResumeLayout(false);
            sidebarGradientPanel.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private System.Windows.Forms.Timer SidebarTransiton;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2GradientPanel ControlGPanel2;
        private Guna.UI2.WinForms.Guna2Button ExitBtn;
        private Guna.UI2.WinForms.Guna2Button ExpandBtn;
        private Guna.UI2.WinForms.Guna2GradientPanel sidebarGradientPanel;
    }
}