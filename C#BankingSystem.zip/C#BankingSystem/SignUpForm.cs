﻿namespace C_BankingSystem
{
    public partial class SignUpForm : Form
    {
        LoginForm loginForm;
        public SignUpForm()
        {
            InitializeComponent();
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            loginForm = new LoginForm();
            loginForm.Show();

        }

        private void ShowBtn_MouseDown(object sender, EventArgs e)
        {

            PasswordTxt2.PasswordChar = '\0';
        }
        private void ShowBtn_MouseUp(object sender, EventArgs e)
        {

            PasswordTxt2.PasswordChar = '*';
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        /*private void LoginForm_FormClosed(object? sender, FormClosedEventArgs e)
        {
            loginForm = null;
        }*/

        public static implicit operator bool(SignUpForm v)
        {
            throw new NotImplementedException();
        }
    }
}
